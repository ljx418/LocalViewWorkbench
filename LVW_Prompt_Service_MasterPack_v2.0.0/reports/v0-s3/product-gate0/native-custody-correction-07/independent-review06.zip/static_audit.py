"""Read-only blob/hash/AST audit; never imports reviewed code or reads live counter."""
from pathlib import Path
import subprocess,json,hashlib,ast
out=Path(__file__).resolve().parent
root=Path('/mnt/c/workspace/videoworkline/localviewworkbench/LVW_Prompt_Service_MasterPack_v2.0.0')
impl=Path('/home/administrator/orca/workspaces/LocalViewWorkbench/lvw-v1-d0-implement')
repo=out.parents[4]
p=json.loads((out/'root-frozen-plan.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest();audit={}
for key in ['dependency_pins','toolpins']:
 rows=[]
 for path,digest in p[key].items():
  f=Path(path);actual=h(f.read_bytes()) if f.is_file() else None;rows.append({'path':path,'expected':digest,'actual':actual,'match':actual==digest})
 audit[key]=rows
rows=[]
for k,v in p['stdlib_pins'].items():
 actual=h(Path(v['path']).read_bytes());rows.append({'name':k,**v,'actual':actual,'match':actual==v['sha256']})
audit['stdlib_pins']=rows
rows=[]
for path,digest in p['sourcepins'].items():
 if str(impl)+'/' in path:
  rel=path[len(str(impl))+1:];b=subprocess.check_output(['git','-C',str(impl),'show','4287090b464d16f398b92797d8f5595359fcb442:'+rel]); local=repo/rel;lb=local.read_bytes() if local.is_file() else None;rows.append({'path':path,'expected':digest,'candidate_sha256':h(b),'candidate_match':h(b)==digest,'local_sha256':h(lb) if lb is not None else None,'local_match':lb==b if lb is not None else None})
 else:rows.append({'path':path,'match':h(Path(path).read_bytes())==digest})
audit['sourcepins']=rows
for n in ['v0_s3_native_custody.py','v0_s3_native_broker.py','test_v0_s3_native_custody.py']:
 rel='LVW_Prompt_Service_MasterPack_v2.0.0/tools/'+n;b=subprocess.check_output(['git','-C',str(impl),'show','37d938b:'+rel]);audit.setdefault('local_history',{})[n]=b==(repo/rel).read_bytes()
rel='LVW_Prompt_Service_MasterPack_v2.0.0/tools/open_lvw_browser.cmd';lb=(repo/rel).read_bytes();b=subprocess.check_output(['git','-C',str(impl),'show','4287090:'+rel]);audit['cmd']={'sha256':h(lb),'normalized_match':lb.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n')}
r=json.loads((out/'evidence/native-custody-correction-03.receipt.json').read_text());audit['receipt']={k:v for k,v in r.items() if k not in ['reports','selected','collected']};audit['receipt']['selected_match']=r['selected']==p['nodeids'];audit['receipt']['collected_match']=r['collected']==p['nodeids'];audit['receipt']['call_order_match']=[x.get('nodeid') for x in r['reports']]==p['nodeids'];audit['counter_evidence_equal']=(out/'evidence/counter-before.json').read_bytes()==(out/'evidence/counter-after.json').read_bytes();audit['plan_sha256']=h((out/'root-frozen-plan.json').read_bytes())
asts={}
for f in (out/'candidate').iterdir():
 tree=ast.parse(f.read_text());asts[f.name]={'lines':len(f.read_text().splitlines()),'definitions':[{'name':n.name,'line':n.lineno,'end':n.end_lineno} for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.ClassDef))]}
(out/'source-static-index.json').write_text(json.dumps(asts,indent=2));(out/'pin-evidence-audit.json').write_text(json.dumps(audit,indent=2))
auth=['AGENTS.md','.agent-governance/README.md','plans/execution-control.json','docs/24_EXECUTION_MASTER_PLAN.md','reports/v0-s3/product-gate0/native-custody-correction-05/contract.md','reports/v0-s3/product-gate0/native-custody-correction-05/regression-obligations.json','reports/v0-s3/product-gate0/native-custody-correction-05/received-review/review.md','reports/v0-s3/product-gate0/native-custody-correction-06/contract.md','reports/v0-s3/product-gate0/native-custody-correction-06/decision.json']+[str(x.relative_to(root)) for x in (root/'reports/v0-s3/product-gate0/native-custody-correction-06/validation-plan-01').iterdir() if x.is_file()]
(out/'authority-hashes.json').write_text(json.dumps({x:h((root/x).read_bytes()) for x in auth},indent=2))
print({k:(len(v),sum(x.get('match',False) for x in v)) for k,v in audit.items() if k in ['dependency_pins','toolpins','stdlib_pins']});print('history',audit['local_history']);print('cmd',audit['cmd']);print('candidate_sources',all(x.get('candidate_match',x.get('match')) for x in rows));print('receipt',audit['receipt']['call_order_match'])
