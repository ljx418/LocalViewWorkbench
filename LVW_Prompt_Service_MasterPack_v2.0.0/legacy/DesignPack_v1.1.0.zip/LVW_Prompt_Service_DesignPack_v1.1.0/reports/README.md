# 本包设计与原型验证说明

本目录仅保存**设计文档静态检查与独立 HTML 原型的浏览器模拟测试**，不含真实 LVW 软件的执行结果。V1/V2/V3 产品验收初始全部 `NOT_RUN`。

- `VALIDATION.md`：v1.1.0 的静态合同、HTML 交互、浏览器 viewport 检查，含工具限制。
- `validation/html-1440-top.png`、`html-390-top.png`：设计总览桌面和移动端预览截屏；全页也保留供查看。
- 未来 `reports/R0...R5`：由本地 Codex 在目标 Windows/4090 环境真实执行后写入，不能从此目录复制 PASS。

**重要：** 本次并未实际编译或启动 React/TS/Vite 产品代码；`START_HERE.html` 是独立的目标体验草图而不是应用实现。真实前端项目必须由 R1 新建并做 F01–F05 验收。
