# LVW v1.1.0 · 文档包与 HTML 预览实际检查

日期：2026-10-26。范围：**设计包本身**，不涉及目标机产品/Gemma4 GPU/真实离线/项目群 E2E。

| 项目 | 本次执行及结果 | 边界 |
|---|---|---|
| `python tools/verify_pack.py` | 169 项静态结构/JSON/合同/跨表映射检查，无错误（首次） | 验证设计包结构与已提供示例，不证明应用实现 |
| JSON Schema | Draft 2020-12 核查 + 两个业务样例校验 | 不能代替实际 Pydantic/OpenAPI 生成 |
| Node inline JS parse | `node --check` 通过 | 不是 React/Vite 生产构建 |
| Chromium 1440×900、390×844、768×960、1920×1080 | 静态 HTML `set_content` 渲染无横向溢出、页面错误0 | 由于受控浏览器阻断本地文件及回环 URL 导航，未测试 `file://` / HTTP 导航本身；HTML 相对链接由静态检查覆盖 |
| 交互模拟 | V1/V2/V3 标签切换、科幻/H3 编译示例、JSON 模拟下载均通过 | 仅本地演示，不调用 Ollama/真实 API |
| 前端产品 | **NOT_RUN** | React/TS/Vite 源码不在设计包中，需 R1 实施 |
| GPU、断网、实际视频、第三方集成 | **NOT_RUN** | 必须本地 Codex 按 A01–A22 与 F01–F07 执行 |

说明：`MANIFEST.sha256` 为设计包内容校验和，不应视为模型验证或第三方软件供应链签名。当前 `plans/acceptance_cases.json` 和 `plans/frontend_checks.json` 均保留 NOT_RUN。
