# Codex 开发启动指令 · LVW Prompt Service v1.1.0

你是开发/验收实施者。当前仅有**开发规格**，不得宣称任何 V1/V2/V3 已完成。

## 读取顺序（先做再执行）

1. `README.md`、`AGENTS.md`、`docs/00_POSITION_AND_ADR.md`、`docs/10_OPEN_SOURCE_REUSE.md`、`docs/11_FRONTEND_ENGINEERING.md`。
2. 阅读 `docs/01_PRD.md` 至 `docs/09_SOURCE_NOTES.md` 与 `docs/12_CHANGELOG_AND_CROSSWALK.md`。
3. 读取 `contracts/`、`plans/tasks.json`、`plans/acceptance_cases.json`、`plans/frontend_checks.json`、`plans/reuse_matrix.json`、`plans/legacy_task_crosswalk.json`。
4. 运行 `python tools/verify_pack.py`；这只核验文档自身。
5. 查看目标代码仓库 `git status`、本机 GPU/Windows/Ollama/ComfyUI/Prompt Assistant 环境；禁止覆盖用户现有工作流或改动其他项目。

## 已冻结的实现路线

- **前端：React + TypeScript + Vite + CSS Modules/原生 CSS**。明确**不使用 Gradio、NiceGUI**；V1 不引入 Next.js、独立 UI 服务器、重型状态管理库或复杂组件套件。Node 仅用于开发/构建，正式由 FastAPI 托管前端 `dist/`。
- **后端：FastAPI + Pydantic + httpx + Python sqlite3 + Pillow + FFmpeg**；本地 Ollama 原生 REST `http://127.0.0.1:11434/api/chat` + 用户已安装的 `gemma4:26b`；业务逻辑不依赖 ComfyUI 进程。
- **复用：Prompt Assistant 只在 R0 验证 API 和模板能力，提取可合法复用的规则与错误测试用例；优先直接复用 Ollama 结构化输出，不再自行实现视觉模型。** V2 使用 PySceneDetect / FTS5 / MCP Python SDK v2；V3 连接 ComfyUI 原生 API。
- **安全/边界**：无独立 NSFW 审核、无内容审批阻断；保留文件安全、最小权限、外部注入隔离、模型错误人工兜底。不得承诺模型内部永不拒答。
- 原 `S0–S11` 已迁移为 **R0–R5**；从现在起 `plans/tasks.json` 是唯一有效任务源。旧任务 `legacy/` 只用于追踪、禁止照旧执行。

## 分阶段门禁（避免 S0 死锁）

**R0 是 Spike，不是 V1 完整验收。** R0 只需要真实检查模型可用性、插件复用能力、离线/资源初步风险。A09（完全离线）、A10（完整性能）、A11（迁移）在 R2 的 V1 Release Gate 才能最终 PASS；R0 不得因它们尚未 PASS 阻塞允许继续开发的 S1 等效任务。R0 没有模型也可以先推进纯人工功能，但 `V1_ACCEPTED` 必须有实机 A02 证据。

- **R0 基线与复用验证**：实际 `gemma4:26b` 单图和 4 帧、Prompt Assistant、Ollama 原生对比、依赖/许可证/缓存/显存；只读，给出 REUSE/WRAP/BUILD/DEFER/REMOVE 结论。
- **R1 V1 轻 SPA + 基础服务**：React + TS + Vite 工程、FastAPI、人工镜头卡、导入、确定性模板编译、类型化 API、测试。无模型也能操作。
- **R2 V1 视觉/持久化/交付**：Ollama 结构化输出+失败退回 raw、单 GPU 队列、修订不可变、离线打包、真实 GPU、22项中的 A01–A12 及 F01–F05 全量验收。
- **R3 V2 影像资产**：PySceneDetect + PTS/VFR、FTS5、风格配方、React 资产检索视图、SQLite 迁移。
- **R4 V2 Agent 接口**：MCP 官方 SDK v2 stdio、小工具白名单、幂等恢复、V2 A13–A17 + F06 及 V1 全回归。
- **R5 V3 项目群适配/交付**：Navia 授权导入、Narralens 返回 Prompt 建议、ComfyUI 白名单执行、迁移回滚、V3 A18–A22 + F07，V1/V2 全回归。

## 必须实际产出（不能只输出报告）

每阶段实现真实代码、自动测试、验收证据、错误修复和阶段总结；API、前端 TypeScript、Schema 和文档同步更新。阶段工件 `reports/Rx-stage-report.json`，字段包括 `git_sha / env / build / tests / real_gpu / network / blockers / upstream_reuse / changed_files / gate`。

`PASS` 必须有日志/测试/真实样本；无证据只可 `NOT_RUN` 或 `BLOCKED`。原设计包现有状态均为 `NOT_RUN`。若缺少 Navia/Narralens 稳定合同，R5 可以实现 mock contract adapter **但不得通过真实 A18/A19/A22**。

## 首条可复制指令

> 读取 LVW v1.1.0 文档包（README、AGENTS、CODEX_START、docs、plans、contracts）。先只读检查本机安装环境、git 工作树和 Prompt Assistant/Ollama 实际接口，按 R0 完成真实复用审计和最小单图/四帧 smoke；记录真实日志与资源，不改动旧 ComfyUI 工作流、不下载新模型。R0 通过后按 R1→R2 开发 FastAPI + React + TypeScript + Vite 正式 V1；不得使用 Gradio/NiceGUI。优先复用上游能力，人工编辑/保存/导出独立于模型。按 A01–A12 与前端 F01–F05 在目标 Windows/4090 上真实验收。完成 V1 才推进 R3–R4、R5。每一步保留失败与 BLOCKED，不允许模拟通过。
