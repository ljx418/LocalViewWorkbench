#!/usr/bin/env python3
"""Static DESIGN-PACK verification. This is not a product acceptance test."""
import json
import re
import sys
from pathlib import Path
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parent.parent
errors=[]
checks=0

def check(condition,label):
    global checks
    checks += 1
    if not condition: errors.append(label)

def load(path):
    p=ROOT/path
    check(p.is_file(),f'missing {path}')
    if not p.is_file():return None
    try:
        data=json.loads(p.read_text('utf-8'))
        check(True,f'valid json {path}')
        return data
    except Exception as e:
        check(False,f'invalid json {path}: {e}')
        return None

needed=['README.md','AGENTS.md','CODEX_START.md','START_HERE.html',
        *[f'docs/{n:02d}_{s}.md' for n,s in enumerate([
            'POSITION_AND_ADR','PRD','UX_TARGET','ARCHITECTURE','ROADMAP','BUILD_PLAN',
            'ACCEPTANCE','SECURITY_AND_MIGRATION','API_AND_DATA','SOURCE_NOTES',
            'OPEN_SOURCE_REUSE','FRONTEND_ENGINEERING','CHANGELOG_AND_CROSSWALK'])],
        'plans/tasks.json','plans/acceptance_cases.json','plans/frontend_checks.json',
        'plans/reuse_matrix.json','plans/legacy_task_crosswalk.json','plans/requirements_traceability.json',
        'legacy/tasks_S0-S11_v1.0.0.json','contracts/frontend-integration.contract.json',
        'contracts/shot-spec.schema.json','contracts/prompt-revision.schema.json',
        'contracts/model-run.schema.json','contracts/media-ref.schema.json']
for n in needed:check((ROOT/n).is_file(),f'missing {n}')

j={str(p.relative_to(ROOT)):load(str(p.relative_to(ROOT))) for p in sorted(ROOT.rglob('*.json'))}
tasks=(j.get('plans/tasks.json') or {}).get('tasks',[])
old=(j.get('legacy/tasks_S0-S11_v1.0.0.json') or {}).get('tasks',[])
cases=(j.get('plans/acceptance_cases.json') or {}).get('cases',[])
front=(j.get('plans/frontend_checks.json') or {}).get('cases',[])
requirements=(j.get('plans/requirements_traceability.json') or {}).get('requirements',[])
crosswalk=(j.get('plans/legacy_task_crosswalk.json') or {}).get('mappings',[])
check([t.get('task_id') for t in tasks]==[f'R{i}' for i in range(6)],'R0-R5 authoritative task list')
check({t.get('task_id') for t in old}=={f'S{i}' for i in range(12)},'legacy stage list')
check({c.get('case_id') for c in cases}=={f'A{i:02d}' for i in range(1,23)},'22 acceptance IDs preserved')
check({c.get('case_id') for c in front}=={f'F{i:02d}' for i in range(1,8)},'F01-F07 frontend checks')
check({r.get('requirement_id') for r in requirements}=={f'R{i:02d}' for i in range(1,21)},'R01-R20 requirements')
check({m.get('legacy_stage') for m in crosswalk}=={f'S{i}' for i in range(12)},'all legacy stages mapped')
case_ids={c.get('case_id') for c in cases}
front_ids={f.get('case_id') for f in front}
work=set();releases=set();f_releases=set()
for t in tasks:
    work.update(t.get('work_on_acceptance_ids',[]))
    releases.update(t.get('release_gate_ids',[]))
    f_releases.update(t.get('frontend_gate_ids',[]))
    check(set(t.get('work_on_acceptance_ids',[])).issubset(case_ids),'unknown acceptance work refs '+t.get('task_id','?'))
    check(set(t.get('release_gate_ids',[])).issubset(case_ids),'unknown release gate refs '+t.get('task_id','?'))
    check(set(t.get('frontend_gate_ids',[])).issubset(front_ids),'unknown front gate refs '+t.get('task_id','?'))
    check(t.get('status')=='NOT_RUN','task pretends accepted '+t.get('task_id','?'))
check(releases==case_ids,'not all 22 release cases gated')
check(f_releases==front_ids,'not all 7 front cases gated')
check(not tasks[0].get('release_gate_ids'),'R0 cannot require full product acceptance')
for c in cases+front:
    check(c.get('status')=='NOT_RUN' and c.get('evidence_path') is None,'premature product PASS '+c.get('case_id','?'))
check(set(t.get('task_id') for t in tasks[1:])=={f'R{i}' for i in range(1,6)},'tasks sequencing')

try:
    import jsonschema
    from jsonschema import Draft202012Validator
    for name in ['shot-spec','prompt-revision','model-run','media-ref']:
        schema=j.get(f'contracts/{name}.schema.json')
        if schema:
            Draft202012Validator.check_schema(schema)
            check(True,'JSON schema valid '+name)
    for name in ['shot-spec','prompt-revision']:
        data=j.get(f'examples/{name}.example.json')
        schema=j.get(f'contracts/{name}.schema.json')
        if data is not None and schema is not None:
            for e in Draft202012Validator(schema).iter_errors(data): errors.append(f'Invalid example {name}: {e.message}')
            checks+=1
except ImportError:
    print('NOTE: jsonschema unavailable; JSON files parsed, schema checks not run')
except Exception as e:
    errors.append('Schema validation error: '+str(e))

html=(ROOT/'START_HERE.html').read_text('utf-8')
check('React' in html and 'Vite' in html and 'R0' in html and 'Gradio' in html,'HTML shows upgrade')
check('S0—S5' not in html and 'S0–S11 顺序' not in html,'HTML no obsolete plan')
check(not re.search(r'<script[^>]+src\s*=\s*["\']https?://|<link[^>]+href\s*=\s*["\']https?://|@import\s+url\s*\(\s*["\']?https?://',html,re.I),'HTML no remote runtime resources')
class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag in ('a','link','script','img'):
            d=dict(attrs)
            target=d.get('href') if tag in ('a','link') else d.get('src')
            if target:self.links.append((tag,target))
links=Links();links.feed(html)
for tag,target in links.links:
    if target.startswith(('#','https:','http:','mailto:','data:')): continue
    check((ROOT/target.split('?')[0]).is_file(),f'HTML local link missing {target}')
for x in ['docs/01_PRD.md','docs/02_UX_TARGET.md','docs/03_ARCHITECTURE.md','docs/04_ROADMAP.md','docs/05_BUILD_PLAN.md','docs/06_ACCEPTANCE.md','docs/10_OPEN_SOURCE_REUSE.md','docs/11_FRONTEND_ENGINEERING.md','CODEX_START.md']:
    check(f'href="{x}"' in html or f'href=\'{x}\'' in html,f'HTML lacks required doc {x}')

frontend=(j.get('contracts/frontend-integration.contract.json') or {})
check(frontend.get('frontend_stack')==['react','typescript','vite','css-modules'],'frontend frozen tech stack')
check(frontend.get('deployment',{}).get('runtime_node_required') is False,'Node-free production runtime')
check(frontend.get('deployment',{}).get('browser_to_ollama_direct') is False,'No direct browser Ollama')
check(frontend.get('manual_flow_must_work_without_model') is True,'Manual mode must work')
check(frontend.get('immutable_revision_required') is True,'Immutable revisions')
check(frontend.get('content_auto_moderation_required') is False,'No automatic content gating')

print(f'Static design-pack checks: {checks} ; errors: {len(errors)}')
for e in errors:print('FAIL:',e)
print('IMPORTANT: document/HTML verification only; GPU, real API, frontend source, full offline and V1-V3 app acceptance remain NOT_RUN.')
sys.exit(0 if not errors else 1)
