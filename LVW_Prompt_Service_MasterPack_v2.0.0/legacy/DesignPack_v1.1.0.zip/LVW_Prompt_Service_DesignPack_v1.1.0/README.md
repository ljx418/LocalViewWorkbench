# LVW Prompt Service｜视觉提示词与镜头创作资产服务

> **设计包 v1.1.0（2026-10-26）** · `IMPLEMENTATION_GUIDANCE_ONLY` · **产品代码未在目标机运行，V1/V2/V3 验收均为 NOT_RUN**

**入口**：阅读 `START_HERE.html`（单文件离线设计预览）；在本地 Codex 打开 `CODEX_START.md`；工程 agent 还应读取 `AGENTS.md`。

## v1.1 相比 v1.0 改了什么？

1. **明确拒绝 Gradio/NiceGUI 等 Python UI 框架**；正式前端冻结为 **React + TypeScript + Vite + 原生 CSS/CSS Modules**。保留轻 SPA、类型化 API、可持续扩展的前端结构。Node.js **仅在构建阶段使用**，发布包不需要 Node 运行服务。
2. 实现路线改为 **上游复用优先**：已安装的 `yawiii/ComfyUI-Prompt-Assistant` 用于 R0 代码/规则/兼容验证；正式 V1 后端独立 FastAPI，使用本机 Ollama 原生 `/api/chat`，**运行时不依赖启动 ComfyUI**。只移植核实许可与兼容性的规则，不引入插件的大量依赖。
3. 使用 **Ollama Vision + Structured Outputs + Pydantic** 减少模型集成/解析代码；失败始终保留原始响应与人工路径，不能为了满足 JSON 强行吞掉结果。
4. 新增 **R0–R5 六阶段**执行计划与 S0–S11 迁移映射；旧的 `A01–A22` **22 项 P0 验收**保留，不改号，另外新增 React 前端子检查 F01–F07。
5. 修复旧版 `S0` 的不合理门禁：**R0 只做能力探测；完整离线、资源、迁移是 V1 Release Gate，不在 R0 强行声明 PASS**。
6. V2 复用 **PySceneDetect、SQLite FTS5、官方 MCP Python SDK v2**；V3 通过薄适配器连接 Navia、Narralens 和 ComfyUI 原生队列。不安装 Dify、FiftyOne、LangGraph、Redis、Postgres、多套 VLM 服务。
7. 增加前端工程边界、复用清单、构建包预算、风险、可执行任务/验收映射与变更记录。

## 项目群与单一权威

| 模块 | 拥有的权威 | LVW 责任边界 |
|---|---|---|
| Navia | 授权网页、视频证据与本地知识引用 | LVW 只经用户明确选择接收来源引用；不读取凭据 |
| Narralens | 视频制作主流程、生产镜头、剪辑、质量复检、发布 | LVW 返回 **Prompt 建议/版本**；不更改 Narralens 生产状态 |
| **LVW** | 可观察视觉信息、创作意图、PromptSpec、风格配方和不可变修订 | 轻前端、服务后端、结构化资产；**不是第二个视频工作台** |
| Ollama / ComfyUI | VLM 推理/生图视频执行 | 各自负责运行；LVW 不复制生成引擎与视频编辑器 |
| Codex/Claude Code | 有限工具调用、代码生成与测试 | 不能越过路径、工作流、资源与数据权限边界 |

## 当前本机基线（来自用户本地 Agent 盘点，未经本轮实机复核）

Windows + RTX 4090 24GiB VRAM + 32GiB RAM，ComfyUI 0.37.0 + Prompt Assistant，Ollama 监听 `http://127.0.0.1:11434`，有 `gemma4:26b` Q4_K_M 可视模型及其它已有模型。R0 必须检测实际版本、许可、视觉能力、上下文、显存、回收与断网状况。不得因已有 H3 Heretic 视觉编码器就把它当成独立生成式 VLM。

## 版本目标

- **V1**：浏览器导入图片/短视频、Gemma4 视觉反推、六创作模式、四目标编译、人工编辑与不可变修订、SQLite、导出、单 GPU、离线 Windows 包。React 轻 SPA，仅一个工作台视图。
- **V2**：PySceneDetect + 准确 PTS/VFR、可检索镜头/风格配方、FTS5、批处理与恢复、MCP stdio，React 扩展资产视图。
- **V3**：Navia 授权证据、Narralens Prompt 合同、ComfyUI 工作流白名单、跨项目版本协商、项目数据迁移/升级回滚。外部系统不就绪时如实 BLOCKED。

## 不变的硬边界

**内容审核由用户负责**。本项目不增加独立 NSFW 自动审核模型、过滤和审批阻断；模型自身拒答可能出现。任何模型不可用/拒答/OOM 都不能锁住**人工编辑、版本保存、复制、导出**；不取消系统与文件安全保护。

**完全本地运行**：前端不直连 Ollama，不加载 CDN 字体/脚本，不调用云 API；构建端下载依赖，运行端无 npm/pip/install/update 网络需求，默认仅绑定 loopback。媒体只读/受控路径、上传上限、提示词与媒体指令隔离。

## 目录快速索引

- `docs/00_POSITION_AND_ADR.md`：项目边界与冻结的架构决策
- `docs/01_PRD.md`：R01–R20 需求与范围
- `docs/02_UX_TARGET.md`：React SPA 分步体验与失败路径
- `docs/03_ARCHITECTURE.md`：模块、数据、队列、前后端边界
- `docs/04_ROADMAP.md`：V1/V2/V3 范围、工期与验收门禁
- `docs/05_BUILD_PLAN.md`：R0–R5 工作包（从已有工具验证出发）
- `docs/06_ACCEPTANCE.md`：A01–A22 与 F01–F07
- `docs/07_SECURITY_AND_MIGRATION.md`：威胁、离线、Windows 包、回滚
- `docs/08_API_AND_DATA.md`：API、PromptSpec、版本与互通合同
- `docs/09_SOURCE_NOTES.md`：事实来源/未验证事项
- `docs/10_OPEN_SOURCE_REUSE.md`：复用、适配、暂缓、明确不引入
- `docs/11_FRONTEND_ENGINEERING.md`：React + TS + Vite 前端工程合同
- `docs/12_CHANGELOG_AND_CROSSWALK.md`：v1.0 → v1.1 变更与向后映射
- `plans/tasks.json`：**唯一有效 R0–R5 执行源**；`legacy/tasks_S0-S11_v1.0.0.json` 只读历史
- `plans/acceptance_cases.json`：A01–A22 的 NOT_RUN 验收；`plans/frontend_checks.json`：F01–F07
- `plans/reuse_matrix.json`、`plans/legacy_task_crosswalk.json`：机器可读复用/迁移映射
- `contracts/`、`examples/`：原 Schema、示例及 V1 前端合同
- `tools/verify_pack.py`：设计静态校验（**不是产品验收**）

**版权和许可**：开源应用代码、模型权重与第三方素材是不同许可。插件规则只能在许可与来源核对之后适配，不应盲目复制完整插件源码。`START_HERE.html` 是离线可读的**设计预览**，不代表已经实现 React 前端。
