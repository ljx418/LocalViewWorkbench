# 12｜v1.0 → v1.1 变更记录与旧工作包映射

## 决策摘要

用户于 2026-10-26 明确拒绝 Gradio，并接受此前其他开源复用与计划压缩建议。正式目标架构仍然是 **轻前端、服务化、重后端与逐步增长的结构化资产库**；更改的是**前端技术栈与工作包组织**，不是放弃原 PRD 对实际影像/镜头/人工版本的要求。

| 维度 | v1.0.0 | v1.1.0 | 效果 |
|---|---|---|---|
| 前端 | 原生静态 HTML/CSS/JS；升级框架未冻结 | **React + TypeScript + Vite**，生产静态 dist，CSS Modules | 开发期多一步构建，后续资产 UI 更可维护 |
| Gradio | 无（上轮复用建议引入） | **明确禁用**，也不采用 NiceGUI | 用户偏好落实为 ADR + 静态检查 |
| VLM API | Ollama 原生 Vision | 不变；加入 Structured Outputs + raw fallback | 省掉自研 JSON 修复器 |
| Prompt Assistant | 本机已安装，原文只描述可核实 | R0 专项复用审计，不作为 V1 运行前置 | 最大化复用又避免耦合 |
| 开发阶段 | S0–S11，12阶段 | **R0–R5，6阶段**；旧编号只读历史 | 更短、可按产出验收 |
| 验收 | A01–A22 | 原 22 项保留 + F01–F07 UI 子检查 | 保留验收强度，修复原 R0/S0 死锁 |
| 视频 | V1 FFmpeg；V2切镜PTS | 不变，明确 V2 复用 PySceneDetect | 少造算法 |
| Agent | V2 MCP v2 | 不变，固定业务 stdio 薄适配 | 不上大 Agent 框架 |
| V3 项目群 | Navia/Narralens/ComfyUI 适配 | 不变，强调需要真实接口 E2E | 不冒称对端已实施 |

## 原 S0–S11 到新 R0–R5（机器版本见 `plans/legacy_task_crosswalk.json`）

| 原阶段 | 新阶段 | 变更 |
|---|---|---|
| S0 | R0 | S0 把完整离线/性能放作门禁的错误修复为 R0 探测与最终 V1 门禁分离 |
| S1 | R1 | 静态页改 React+TS+Vite SPA，业务仍只一个工作台 |
| S2 | R1/R2 | 安全媒体入口 R1，真正视频抽帧/VLM 联调 R2 |
| S3 | R0/R2 | R0 验证插件/Ollama，R2 正式 Ollama Adapter 与单 GPU Job |
| S4 | R1/R2 | CPU 模板编译 R1，可选模型建议整合 R2 |
| S5 | R2 | SQLite 不可变版本、备份、Windows 离线包与完整 V1验收 |
| S6 | R3 | PySceneDetect + ffprobe/ffmpeg PTS |
| S7 | R3 | SQLite/FTS5、风格配方与 React资产页 |
| S8 | R4 | MCP v2 stdio + 幂等恢复、任务生命周期 |
| S9 | R5 | Navia evidence 适配 |
| S10 | R5 | Narralens Prompt 合同 |
| S11 | R5 | ComfyUI 白名单、迁移回滚与项目群 E2E |

## 不变的产品约束

- V1仍必须有图像反推、短视频多帧、六种创作模式、四种输出、人工编辑/保存/导出、SQLite修订、真实 4090 与离线打包。
- V2 仍必须有准确 PTS/VFR、资产检索、MCP 和恢复。
- V3 仍需要 Navia、Narralens、ComfyUI 真实集成验收。
- 无独立内容审核/NSFW 审批阻断；不保证模型内部不存在拒答。
- 最终以原 A01–A22 的证据为发布门槛，新增 F01–F07 是对前端质量的明确约束。

## 删除/暂缓的实现负担

不构建 Gradio/NiceGUI、Dify、LangGraph、FiftyOne/MongoDB、独立向量库、多个模型服务器、视频生成执行器、云端账号、独立前端 SSR 服务器。V2 的 Open Image Prompts 仅按需引入风格卡/只读 CLI，不默认附带数 GB 的媒体数据。

## 状态和已知限制

设计包升级已完成不表示 V1/V2/V3 已开发。`START_HERE.html` 可作为交互目标参考，但不代表已存在实际 React/TS/Vite 代码。R0、真实显卡、真实离线与跨项目验收必须本机执行。旧版报告/图片预览不继承为新版实测证据。
