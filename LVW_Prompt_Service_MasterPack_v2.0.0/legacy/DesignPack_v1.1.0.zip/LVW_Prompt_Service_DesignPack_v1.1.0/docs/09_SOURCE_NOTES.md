# 09｜证据来源、版本与未验证事实

## A. 用户提供、**未经当前工具接入目标主机实测**

Windows 电脑 i7-13700KF / RTX4090 24GB / 32GB RAM；ComfyUI 0.37.0、Prompt Assistant 已安装；Ollama `http://127.0.0.1:11434` 和 `gemma4:26b` Q4_K_M；本地还包含 Florence-2、Qwen3-14B、Qwen3-VL text encoders、Heretic H3 编码器。仅据本机 Agent 自检的回报作为**待核实基线**，不作为 V1 验收 PASS。

Navia 提供授权网页/视频理解、证据/个人知识条目；Narralens 管内容生产与质量；ComfyUI 管图像/视频实际执行。用户拒绝 Gradio/NiceGUI，接受其它开源复用与计划压缩建议。

## B. 本次外部公开仓库/官方文档核对（2026-10-26）

| 项目 | 文档/仓库 | 已确认范围 | 尚需本机验证 |
|---|---|---|---|
| yawiii/ComfyUI-Prompt-Assistant | https://github.com/yawiii/ComfyUI-Prompt-Assistant | README 记录 V2.0.6、Ollama 原生路由、图片/视频反推、规则、UI；server.py 可见 VLM API | **已安装插件版本、路由前缀、配置存储、特殊安装差异、许可与输出行为** |
| Ollama Structured Outputs | https://docs.ollama.com/capabilities/structured-outputs | 官方支持模型生成时提供 JSON Schema，包括视觉模型用例 | 本机 `gemma4:26b` 对目标 Schema 稳定性/原文退回机制 |
| Ollama Chat/Vision | https://docs.ollama.com/api/chat ; https://docs.ollama.com/capabilities/vision | 本机多模态图片输入、keep_alive 参数 | 本机显存、吞吐、取消与卸载 |
| React | https://react.dev | UI 库，正式前端选择 | 版本锁定和浏览器端离线构建 |
| TypeScript | https://www.typescriptlang.org | 静态类型与编译 | 锁版本、合同同步 |
| Vite | https://vite.dev/guide/ | React+TS 开发/构建工具，生产可输出静态产物 | 编译 Node 版本与离线 bundle |
| PySceneDetect | https://github.com/Breakthrough/PySceneDetect | 可复用镜头切分能力 | VFR 精确证据映射（需另接 ffprobe/ffmpeg PTS） |
| MCP Python SDK | https://github.com/modelcontextprotocol/python-sdk | v2 稳定 `MCPServer`/stdio 等，2026年10月可固定 v2.3.0 或实测稳定版本 | 实际 Codex/Claude Code 客户端兼容 |
| ComfyUI | https://github.com/Comfy-Org/ComfyUI | 现有本地队列与任务 API | 本机发行版/工作流白名单与双进程 GPU互斥 |
| Open Image Prompts | https://github.com/NanmiCoder/open-image-prompts | 可选风格参考、Skills、只读档案；不是新视频图像反推推理模型 | 无需第一期安装，V2按需离线数据分发与许可审查 |

## C. 本包工程推断与选择（**不是上游已实现**）

React SPA、FastAPI 模块单体、SQLite PromptSpec、业务版本、R0–R5 任务映射、A/F 验收、MCP 工具边界、离线便携包、推荐硬件预算均为本项目设计或估算。不声称插件已经具备 LVW 的不可变修订、PTS、Navia/Narralens 合同与工程验收能力。

## D. 开发开始仍待核实的事实

1. Prompt Assistant 实际安装版本/代码、配置目录、许可证及是否影响现有工作流；是否存在硬编码联网服务。
2. Gemma4 本机视觉能力、Structured Outputs 稳定度、真实 4–8 帧、生成速度、显存峰值与 unloading。
3. 断网环境下 Windows 域名/依赖/CDN 情况；Python 便携包、Vite dist 在目标 OS 下的真正启动。
4. Navia、Narralens 已实施的真实 API/权限合同；不因为描述了目标就认定接口存在。
5. 历史/科学独立金标准与用户版权许可，不把视觉模型自我评价当成独立验收。

**文件包声明**：这是从 v1.0 文档包升级的 v1.1.0 设计，不是代码实现或实机验收结果。
