# 11｜前端工程合同（v1.1 新增）

## 用户决策

**明确拒绝 Gradio。** 不采用任何将 UI 与 Python 推理代码直接绑定的 Python 组件系统。正式前端采用 **React + TypeScript + Vite**，原生 CSS/CSS Modules；FastAPI 发布静态构建产物。本设计 HTML 是一个独立预览文件，不能被误认为生产组件。

## 选型理由

| 属性 | React+TS+Vite 具体收益 |
|---|---|
| V1 最小 | 可以只有一个 SPA、一个视图；无需复杂路由/SSR |
| V2/V3 可扩展 | 组件和状态可逐步扩充资产搜索与集成视图，而不推翻 UI 框架 |
| 分离协议 | 类型化 HTTP API 与后端 Pydantic/OpenAPI 同步，减少前端绕过后端逻辑 |
| 离线交付 | 构建 `dist/` 静态文件与 FastAPI 同源发布，正式运行时无需 Node |
| 测试 | TypeScript 编译、组件测试、浏览器 E2E、无网络资源扫描 |

## V1 项目树与最小组件

```text
frontend/
  index.html
  vite.config.ts
  package.json + package-lock.json
  src/
    main.tsx, App.tsx
    api/{client.ts,types.ts}
    features/workbench/{WorkbenchPage.tsx,MediaInput.tsx,ShotEditor.tsx,
                       AnalysisPanel.tsx,PromptOutputs.tsx,RevisionHistory.tsx}
    components/{Field,Button,StatusBanner,ConfirmDialog}.tsx
    styles/{tokens.css,base.css,workbench.module.css}
```

- `WorkbenchPage` 负责本地草稿 UI 状态，API 持有真源；模型结果只先显示在 `AnalysisPanel`，点击“采纳”后才写入人类草稿。
- `PromptOutputs` 的四种目标可切换，编译只调用本地 `/api/v1/prompts/compile`，不会再触发视觉推理。
- `RevisionHistory` 只读取不可变修订，不允许默默更新旧版本；显示作者、来源域、哈希与 etag 冲突。
- `MediaInput` 只允许用户选择/拖拽，使用 `URL.createObjectURL` 做本地预览并回收 URL，正式上传走受控 multipart。不要在 browser 内用 File System Access API 读取未知系统路径。

## 浏览器/后端边界

```text
DEV: Vite localhost:5173 /api/v1 → proxy 127.0.0.1:<API_PORT>
PROD: FastAPI 127.0.0.1:<LVW_PORT> serves dist/ + /api/v1
```

在开发期将 `/api/v1` 代理到本机后端；生产期仅同源，不给浏览器跨源直连 Ollama。CORS 默认不开对任意来源的通配策略，不将调试配置复制到生产启动器。API 类型以 Pydantic/OpenAPI 为单一事实源，CI 检查类型兼容与必填字段。

## 依赖预算与约束

- 初期直接依赖限为 React、react-dom、TypeScript、Vite、React 类型、测试库（开发依赖）。依赖因实际需求新增且经项目负责人审查；前端不使用 Gradio/NiceGUI，不引入运行时 SSR 服务。
- V1 不默认引入 React Router/Redux/TanStack Query/组件大全/Tailwind 等；确有需求时给出新增包体、维护成本、授权和场景，作为独立 ADR。
- 全局样式以 CSS 变量作为 tokens，业务组件使用 CSS Modules；不依赖外链 icon font、Google Fonts、CDN 或在线翻译服务。
- 所有长耗时操作异步请求；轮询有间隔和取消、离开页面清理订阅；输入避免每个字符都发 API。

## 开发构建与发布

```bash
# 构建机（先下载并锁定依赖，版本以 R0 实测 Node 为准）
cd frontend
npm ci
npx tsc --noEmit
npm run test
npm run build

# 运行包内只包含 frontend/dist 的静态资源，无 npm/node requirement
# 正式 Windows launcher 启动 FastAPI + 已安装本地 Ollama
```

Codex 应冻结 `package-lock.json`、Node/TS/Vite 版本、打包静态资源哈希及第三方许可证，`npm ci --offline` 只有在缓存已备齐时才可以作为构建端验证；**产品运行时不能执行任何依赖下载命令**。

## 前端验收

- F01：TypeScript build 通过，真实 React 工程存在，依赖树不出现 Gradio/NiceGUI。
- F02：360/768/1280/1920px 适配、中文长文本不裁切、键盘焦点可达。
- F03：模型拒答/OOM/取消后的人工保存导出；失败不清空草稿。
- F04：API 类型一致、ETag 冲突可见、不让异步旧响应覆盖新草稿。
- F05：`dist/` 的资源全本地、网络禁用时加载、发布包内无需 npm/node 运行。
- F06/F07：对应 V2 Library、V3 Integrations 的场景浏览器 E2E。
