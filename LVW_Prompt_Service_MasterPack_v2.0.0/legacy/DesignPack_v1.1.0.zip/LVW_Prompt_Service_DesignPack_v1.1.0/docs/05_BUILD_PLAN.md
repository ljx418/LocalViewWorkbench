# 05｜Codex 可执行开发计划：R0–R5（替代 S0–S11）

## 0. 计划来源与阅读规则

`plans/tasks.json` 是机器可读**权威任务清单**；`plans/legacy_task_crosswalk.json` 映射旧 S0–S11，`legacy/tasks_S0-S11_v1.0.0.json` 仅供审计，不执行旧门禁。验收 A01–A22 不改号，阶段 smoke 与最终 Release Gate 分开。每阶段都须真实运行、修复与回归。

### R0 · 上游复用与本机能力 Spike（V1 前置）

- **READ-ONLY**：先 `git status`，记录驱动、Windows、CUDA、Python、ComfyUI、Prompt Assistant、Ollama 模型 manifest/能力、端口/资源与用户数据路径。备份现有插件配置，禁止默认更新。
- 用 1 张真实图片、4 张抽帧分别验证：插件 Ollama 图像/视频反推 API 与直接 Ollama `/api/chat`。对比提示词规则、结构化 JSON、延迟、显存、`keep_alive=0`、异常和返回原文。
- 读取 Prompt Assistant 的许可证、规则存储目录、限制与服务 API；**不复制不符合许可的上游源码**。形成 `reuse-audit.md`、`runtime-benchmark.json`、`reuse-decision.md`、版本与校验和。
- **出门门槛**：选定正式路线 **独立 Ollama B** 的验证结论，列出已知阻断及替代；如 VLM 不可用仍可开 R1 手动功能，但 V1 发布不可越过 A02。A09/A10/A11 仅做初测，不要求在 R0 通过完整产品验收。

### R1 · React 轻 SPA + 基础服务与确定性编译（V1）

- 建立 FastAPI、health/capabilities、受控媒体导入、Shot CRUD、Prompt 编译及单份 typed API client；React+TS+Vite 新项目，CSS Modules，**只一个工作台主界面**。
- 先实现完全无需模型的操作：空镜头→六模式/四目标→自由编辑→纯 CPU 模板编译→保存/复制/TXT或JSON导出。初始 SQLite 表与版本迁移骨架建立。
- 自动化：pytest backend、TS `tsc --noEmit`、Vite build、前端组件测试+Playwright（或既有测试框架，但依赖冻结）；AI 模拟只能测试 UI 状态，不可声称业务 GPU PASS。
- **出门门槛**：A01、A04、A08 的已实现部分和 F01–F04 的相关子检查通过；正式产品失败路径可复现，不能用 HTML 演示代替。

### R2 · 本地视觉推理、版本、安全、打包与 V1 验收

- Ollama provider 支持 image base64/Structured Outputs（按本机版本确认），Pydantic 验证、raw fallback、错误映射与用户不受阻的人工工作稿。视频 FFmpeg/ffprobe 受控解码和 4–8 帧，默认近似时间明确标注。
- 单 worker/持久化 job_id/attempt_id、队列取消/迟到响应防覆盖；锁定 GPU 并发=1 与输入预算；Model unload 请求实测。SQLite 不可变 revision、etag 冲突、备份迁移与打包。
- 使用已安装模型进行真实 A02/A03/A07/A10；断网冷启动 A09、双目录迁移 A11 与产品回归 A01–A12；F01–F05 全量通过。
- **出门门槛**：验收成功才声明 `V1_ACCEPTED`；有工程功能但缺人工质量集 → `ENGINEERING_READY/QUALITY_PENDING`。

### R3 · V2 镜头资产与搜索

- 使用 PySceneDetect 检测剪辑点，保留真实 PTS/VFR（禁止用平均 fps 替代证据时间）。多段素材流式采样；人工校正镜头边界并生成修订。
- SQLite FTS5 索引描述/标签/人工备注，hash 去重，关联 shot/media/revision/style_recipe，批量任务的最小列表；React 新增 Library 视图。
- **门槛**：A13/A14/A17，真实 VFR 和千条媒体引用，无损迁移、旧 Prompt 可检索。

### R4 · V2 MCP 与可靠性

- 使用官方 MCP Python SDK v2 的 `MCPServer`，stdio 最小 5–8 个工具只调用现有 service（列/读镜头、导入授权引用、分析、编译、保存修订、导出、查任务等）；白名单文件根/无任意 Shell/HTTP 外联。
- 完成进程崩溃恢复、重试幂等、取消并发、WAL 一致性备份；真实 MCP 客户端 tools/list / call / errors，复用 R3 UI。
- **门槛**：A15/A16、F06、V1 A01–A12 与 V2 A13/A14/A17 回归均 PASS。

### R5 · V3 项目群薄适配与交付

- Navia：用户显式选择/授权 source_ref，带 citation/rights_note；隔离浏览器凭据。Narralens：`external_project_id/shot_id`→返回 Prompt 版本建议，禁止更新其生产状态。
- ComfyUI：按批准的 `workflow_id`、参数白名单提交原生队列，保存工件引用；跨进程 GPU 资源协调不靠普通 Python lock 假设生效。
- 版本协商、打包迁移/恢复/回滚、离线集成路径和真实 E2E。只在外部合同可真实执行时通过 A18/A19/A22；否则 BLOCKED 且仍可单独使用 LVW。
- **门槛**：A18–A22、F07、V1/V2 全回归，真实失败注入和跨目录迁移均 PASS 才可 `V3_ACCEPTED`。

## 开发中的通用规则

- 每阶段一条线：实现 → 单元/接口/前端构建 → 真实模型（适用时）→ 故障注入 → 验收证据 → 修复复跑 → 阶段报告。
- Windows 原生优先，任何安装/编译只在构建环境进行；运行机零 `npm install`/`pip install`/云账号操作。
- 不能默认下载新视觉模型或更新/删除用户已验证的 ComfyUI 工作流。
- Stage status：`PASS/FAIL/BLOCKED/NOT_RUN`。记录 `reports/Rx-stage-report.json` 与原命令、日志、git SHA、运行资源、网络观察，秘密和原素材不应打包上传。
