# 04｜V1–V3 路线图与版本门槛（复用优先）

## 管理口径：先形成业务闭环，再建设资产，再做项目群互通

| 版本 | 新执行阶段 | 核心产物 | 不属于当前版本 |
|---|---|---|---|
| **V1 · Prompt Workbench** | R0–R2 | React SPA + FastAPI、Ollama 图/短视频反推、六种创作模式、四目标、手动路径、SQLite 修订、离线 Windows 包 | 大型素材库、MCP、多系统联动、真正的视频生成 |
| **V2 · Creative Asset Service** | R3–R4 | PySceneDetect + 真 PTS、镜头/Prompt/风格配方资产检索、FTS5、MCP stdio、批处理恢复、React Library | 自建剪辑器、自动网络采集、视频生成器调度中心 |
| **V3 · Project Group Adapter** | R5 | Navia 显式授权证据、Narralens 镜头合同、ComfyUI 原生任务接口、升级回滚/离线跨项目部署 | 夺取 Narralens 生产状态、通用 SaaS、自动内容门禁 |

## 核心资源前提与里程碑

R0 必须验证 Windows/4090/Gemma4/Prompt Assistant 的实际兼容性；没有实测不得将用户本机盘点当验收结论。V1 为单人单机、单 GPU 任务，依赖 Ollama，**无需 ComfyUI 进程**。从 V2 开始资产实体更丰富，但继续使用同一个 SQLite，不另建 DB 服务。

估计工期（**仅用于规划，不是承诺或实测**）：

| 版本 | 估计新增工程工作日 | 估计累计 | 估计前提 |
|---|---:|---:|---|
| R0 + V1 | **8–14** | 8–14 | 本机模型真实可用；React/Vite 构建端已就绪 |
| V2 | **7–13** | 15–27 | PySceneDetect/MCP 不冲突，已有真实 VFR 样本 |
| V3 | **10–20** | 25–47 | Navia 与 Narralens 提供稳定、可调用的合同 |

说明：相比上一轮 Gradio 复用估算，React/Vite 初期工程化多出部分 UI 工作，但长期修改和扩展成本更可控。R0 首次可用图片反推可优先基于已安装插件形成内部演示，**不能用该演示代替独立 V1 软件验收**。

## 阶段门禁的关键纠正

- **R0 readiness**：实际检查 Ollama 是否装有 `gemma4:26b`、真实单图 smoke、Prompt Assistant 对照、资源初测与许可证清单；不得强制 A09/A10/A11 此时完整 PASS。
- **V1 release**：R1–R2 全功能实现；A01–A12 **全部 PASS**；前端 F01–F05 PASS；有真实 GPU/断网/人工编辑证据才能 `V1_ACCEPTED`。独立画面质量样本不足时 `ENGINEERING_READY / QUALITY_PENDING`。
- **V2 release**：A13–A17 与 F06 PASS，V1 全回归 PASS，数据库迁移无损。
- **V3 release**：A18–A22 与 F07 PASS，V1/V2 全回归 PASS；任何 Navia/Narralens 真实合同不可用时只能 `BLOCKED`，不得 mock 宣称集成完成。

## 红线

1. R0 不能因为未完成产品功能而陷入门禁循环。
2. R1/R2 不因前端扩展而偷偷引入 Gradio、Next.js、第二个前端服务。
3. R3/R4 不自建切镜算法、向量数据库或第二个大型 Agent 平台。
4. R5 不把外部项目数据库直接改成 LVW 内部存储，也不让 Prompt 服务执行生产审批。
5. 任何版本的手动编辑/保存/导出不依赖内容审查、GPU 模型可用性或其他项目在线。
