# 08｜API 与数据合同（前后端类型来源统一）

## V1 HTTP API（同源，127.0.0.1）

| Method | Route | 语义 / 保证 |
|---|---|---|
| GET | `/health` | 服务活性，不泄露素材路径 |
| GET | `/api/v1/capabilities` | 本地 Ollama/Gemma4 能力 + `manual_mode:true`，超时可降级 |
| POST | `/api/v1/media` | 受控 multipart，返回 hash/media_id/基本元数据；不允许不经授权的绝对路径读取 |
| POST | `/api/v1/jobs/analyze` | 202 job_id, 资源约束/idempotency_key, 不保存为人工 revision |
| GET | `/api/v1/jobs/{job_id}` | 状态/错误/引用/尝试次数；可轮询，后续可增事件流 |
| POST | `/api/v1/jobs/{job_id}/cancel` | 幂等取消、attempt 防迟到覆盖 |
| POST | `/api/v1/shots` | 允许无媒体的人工镜头 |
| GET/PUT | `/api/v1/shots/{id}` | PUT 使用 `If-Match` + `ETag`，冲突 HTTP 409 |
| POST | `/api/v1/prompts/compile` | **纯 CPU 确定性**模板编译，可接受无模型手稿 |
| POST | `/api/v1/prompts/revisions` | append-only 人工/模型建议修订，返回不可变 id/hash |
| GET | `/api/v1/prompts/revisions/{id}/export?format=txt|json` | 只按用户授权对象导出 |

`/api/v1/assets?q=...`、`/api/v1/style-recipes` V2 才添加；MCP v2 V2 才是发布合同；Navia/Narralens/ComfyUI V3 才有真实对接合同。

## Schema 的单一真源

- Pydantic (backend) 执行实时 API 入参/出参校验，生成 OpenAPI；前端生成或严格检查 `api/types.ts` 与 OpenAPI 的一致性。
- 本包原有 `contracts/shot-spec.schema.json`、`prompt-revision.schema.json`、`media-ref.schema.json`、`model-run.schema.json` 表示**核心业务字段合同**，必须验证 Pydantic 与这些字段的双向映射，不能另建三个互相矛盾的 Schema。
- 成功 `{data, request_id, schema_version}`；失败 `{error:{code,message,retryable},request_id}`。上传/任务可异步，用户工作稿不得由自动任务响应无条件更新。

## 核心错误码

| 错误码 | 场景与处理 |
|---|---|
| `MODEL_UNAVAILABLE` | 无 Ollama 或权重缺失；人工模式持续可用 |
| `MODEL_REFUSAL` | 模型自身未返回所需结果；非内容违规判定 |
| `MODEL_TIMEOUT` | 推理超时；保存 raw/进度，人工可编辑 |
| `GPU_OOM` | 单卡资源不足；不强制启动别的模型 |
| `PARSE_PARTIAL` | Structured Outputs/JSON 不完整；保留 raw 不丢失 |
| `MEDIA_INVALID` / `PATH_FORBIDDEN` | 文件格式/来源越权；拒绝解码，人工可新建 |
| `REVISION_CONFLICT` | If-Match 不匹配；返回当前 etag，禁止静默覆盖 |
| `JOB_CANCELLED` | 取消/晚到尝试无权再写数据 |

## 状态权威与数据来源

`observation`、`inference`、`user_evidence`、`creative_intent` 明确区分；Prompt 编译器不把 inferred period/location 当 confirmed data。历史/科学用户证据带 source ref；生成器 Prompt 与图像输入原始事实独立保存。

## V3 项目群最小合同

Narralens→LVW：`{external_project_id,external_shot_id,source_refs[],creative_brief,target,request_id,authorization_scope}`。
LVW→Narralens：`{prompt_revision_id,shot_spec_id,model_run_id?,compiled_prompt,evidence_refs[],confidence_notes[],contract_version}`。
Navia→LVW：`{navia_knowledge_ref,source_url,citation_id,quote_or_summary,saved_by_user,rights_note?}`，不得包含 cookie/token、默认绝对路径等。
ComfyUI：`{allowed_workflow_id,input_parameters,prompt_revision_id,idempotency_key}` 进入受控工作流映射，结果只返回工件/任务引用。

这些字段是 LVW 设计合同，不代表 Navia/Narralens 已实现对应接口；R5 必须核对实际接口再编写薄适配，真正端到端完成前 A18/A19/A22 保留 BLOCKED。
