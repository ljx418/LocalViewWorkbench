# 07｜威胁模型、完全离线、可移植 Windows 发布

## 1. 人工内容责任与系统安全分开

本项目**不设独立 NSFW 分类/评级、自动敏感词阻断、云审核/审批流程**；用户负责内容判断。模型自身的安全对齐可能导致拒答，本系统记录模型执行状态并保留人工编辑/保存/导出。上述内容自主权不允许被解释为移除文件、权限、GPU 资源或供应链安全保护。

## 2. 攻击路径与最小防线

| 路径 | 防线/测试 |
|---|---|
| 图中文字、网页段落、Prompt 模板企图注入 Agent 指令 | 作为非可信数据；MCP不提供 shell、任意文件操作、联网 fetch；A08/A15 |
| `../`、绝对路径、重解析、符号链接、UNC | 仅受控根和上传；resolve 校验 + 权限白名单；A08 |
| zip bomb、解压炸弹、恶意媒体元数据、超高分辨率视频 | MIME+magic+Pillow/ffprobe 限额、进程超时/限制、软硬资源预算；A08/A10 |
| 模型服务可被前端直连/劫持 | 浏览器只连同源 API；Ollama 地址为固定本机端口；关闭公共监听；F04/F05 |
| NPM/PyPI依赖在运行时联网拉取 | 锁 `package-lock.json`、Python constraints+wheelhouse、构建机封装，离线冷启动抓包；A09 |
| 原 ComfyUI 插件被升级损坏 | 插件只在 R0 读取和对照，不在用户已有实例中做破坏性升级；A02 |
| 生成任务内存竞争导致崩溃 | GPU semaphore=1 只保护 LVW，本机 ComfyUI 竞争需提示/受控协调；A10/A20 |
| 人工稿在重算或升级中丢失 | append-only revision、backup/restore、etag/attempt token；A06/A07/A21 |

## 3. Windows 离线交付目录

```text
LVW/
  releases/<version>/      FastAPI 服务、Python runtime、frontend/dist、FFmpeg、锁定依赖
  launcher/                start/diagnose/backup/restore
  config/                  端口、允许的媒体根目录、Ollama本地模型tag
  data/catalog.sqlite     结构化 shot/prompts/media refs/revisions
  data/artifacts/          缩略图/导出，独立于软件 release
  projects/                选配用户项目包
  reports/                 打码诊断与版本 SHA
  manifests/               bill-of-materials、版本、文件哈希/许可
```

前端 `npm ci && npm run build` 在构建端完成，**正式启动不运行 `npm`/`vite` 或 `node`**；FastAPI 同源托管已经生成的 `dist/`。Windows 发布的 Python 运行环境必须是**实际可启动的便携 runtime**，不能将开发机 `.venv` 直接当跨机器可用包。

使用者目标：0 手动 clone、0 运行时 pip/npm install、0 运行时模型下载、0 CUDA 现场编译。Ollama `gemma4:26b` 保持复用已安装权重，不将 16+GiB 文件重复放到每个项目 ZIP 中。开发者提供检查模型是否存在、依赖状态和导入路径的诊断脚本。

## 4. 单机完全离线约束

`OLLAMA_NO_CLOUD=1` 等配置**只是起点**：阻断出站网络、空 Web 缓存/模型缓存（必要预置本地权重除外）冷启动，测试首页 JS/CSS、API、视觉模型、手工路径、导出；不依赖 CDN、字体、自动更新、远程浏览器扩展或第三方 API。

## 5. 迁移与回滚

- 轻迁移：使用 SQLite backup API 快照（WAL 完整一致），导出项目/Prompt/模板/媒体哈希引用，新系统通过用户选择根目录重绑定。
- 完整迁移：只复制用户**明确选择**的媒体和导出文件，避免整个素材库与模型重复拷贝。
- 新 release 与旧 release 并存。迁移前备份 DB，成功验证后切换 current；回滚是**代码+匹配版本数据库备份**一起回滚。
- CPU/GPU 数据保留测试结果，不跨 Windows/Linux 直接复制 CUDA wheel 当作通用安装包。V3 可单独设计 Linux 发布，不属于 V1。

## 6. 第三方许可

应用代码、Prompt Assistant 插件、Gemma 模型权重和原始媒体各自许可证不同。R0 建完整 `licenses/`、`SBOM`、`upstream-versions.json`；只搬运经许可允许的提示词规则。第三方创作素材不能因为存在 OIP 本地档案中就被当作可自由再发布素材。
