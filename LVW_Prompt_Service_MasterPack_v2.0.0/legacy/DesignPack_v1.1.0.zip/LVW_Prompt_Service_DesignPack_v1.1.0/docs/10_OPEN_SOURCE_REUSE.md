# 10｜开源复用决策与部署成本控制

## 选择准则

优先选 **已安装、可靠、无额外服务、依赖少、可编排、许可证清楚** 的项目；一项功能有成熟组件则不重写算法。必须区分：①直接复用的运行时能力；②参考或对照代码；③新业务逻辑；④后续可选包。

| 组件 | 项目链接 | 等级 | 在 LVW 内的角色 | 备注 |
|---|---|---|---|---|
| **本机 Ollama + gemma4:26b** | https://docs.ollama.com/api/chat | **REUSE/V1** | 视觉推理，Structured Outputs，模型卸载 | 不重复下载模型；V1 真机验证 |
| **ComfyUI Prompt Assistant** | https://github.com/yawiii/ComfyUI-Prompt-Assistant | **REFERENCE/R0** | 规则、Ollama 调用方式与兼容/故障场景对照 | 不是正式 V1 运行时依赖；检查授权/许可证后迁移部分规则 |
| **FastAPI/Pydantic/httpx** | https://fastapi.tiangolo.com | **REUSE/V1** | HTTP 接口、类型合同、Ollama 请求 | 一个服务进程，薄业务层 |
| **React + TypeScript + Vite** | https://vite.dev/guide/ | **REUSE/V1** | 专业轻前端，类型化可扩展 UI | **替代 Gradio**；Node 只用于构建 |
| **SQLite/FTS5** | https://www.sqlite.org/fts5.html | **REUSE/V1/V2** | Prompt 修订与 V2 资产检索 | 不安装外部数据库服务 |
| **FFmpeg/ffprobe/Pillow** | https://ffmpeg.org/documentation.html | **REUSE/V1** | 视频抽帧/媒体读入/尺寸与时间信息 | 流式、最小内存 |
| **PySceneDetect** | https://github.com/Breakthrough/PySceneDetect | **REUSE/V2** | 镜头切分（非时间真值自身） | 精确PTS额外由解码数据支持 |
| **MCP Python SDK v2** | https://github.com/modelcontextprotocol/python-sdk | **REUSE/V2** | stdio Agent 工具入口 | 单一业务函数，不二次实现 MCP协议 |
| **Open Image Prompts** | https://github.com/NanmiCoder/open-image-prompts | **OPTION/V2** | 风格卡与参考提示词检索 | 避免默认拉全图包；注意第三方素材许可 |
| **ComfyUI 原生 API** | https://github.com/Comfy-Org/ComfyUI | **REUSE/V3** | 生图/视频的受控执行 | 只用 workflow 白名单，不重写队列 |

## 不引入与原因

| 不引入 | 原因 |
|---|---|
| **Gradio / NiceGUI** | 用户明确拒绝；组件与交互高度绑定 Python 渲染框架，不利前端长期独立演化 |
| Dify / FiftyOne / LangGraph / CrewAI | V1 确定性视觉/Prompt 流程不需要多 Agent/多服务集群，额外部署与许可成本较高 |
| Ollama 之外额外 vLLM/TGI/独立视觉服务 | 已有本地 Ollama，首期再加模型服务重复消耗资源 |
| React 全栈 SSR/Next.js、Redux、大型 UI 库 | V1 单页面无需 Node 常驻服务器或重量包；V2 根据实证再考虑 |
| Redis/PostgreSQL/MongoDB/向量库 | 单人本地资产规模，SQLite/FTS5 足够；除非出现真实指标瓶颈 |
| 新的模型权重与扩散视频生成器 | 用户已安装 Gemma4 视觉模型，V1 不把视频生成纳入主路径 |

## R0 必须产生的复用审计报告

表头：`component`、`installed_version`、`upstream_revision`、`license`、`interface`、`tests`、`known_bugs`、`dependencies_added`、`decision:REUSE/WRAP/BUILD/DEFER/REMOVE`、`evidence`。

**先验结论**：FastAPI → Ollama 是 V1 正式路径；Prompt Assistant 是参考/验收参照。不允许 Codex 以 R0 两路线比较为由擅自换回“插件进程必须运行”或 Python UI 框架。若正式路径技术不可行，记录 BLOCKED 并提出最小变更 ADR，交由用户定夺。

## 预估压缩机会（计划，非实测）

- 不重建多模态模型：Ollama 已负责图像输入与模型执行。
- 不写前端 SSR/多页面框架：V1 仅 React SPA，一个 `dist/` 静态站点。
- 不建自研文本解析和镜头切分算法：优先 Schema+Pydantic、V2 PySceneDetect。
- 不建完整文件数据库与 Agent 框架：SQLite/FTS5、MCP SDK 足够。
- 不接多个视频生成运行时：V3 复用本机 ComfyUI。

**研发估算**：V1 约 8–14 工作日；V2 新增 7–13；V3 新增 10–20，累计 25–47 工作日。比原 v1.0 的 33–64 工作日范围低，实机/跨项目不确定性仍可改变工期。不可作为验收承诺。
