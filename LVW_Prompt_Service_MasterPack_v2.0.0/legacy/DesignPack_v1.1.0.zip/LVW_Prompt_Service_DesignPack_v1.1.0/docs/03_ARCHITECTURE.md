# 03｜目标架构：轻 React 前端 + 模块化单体服务 + 结构化资产

## 1. 部署拓扑（实际开发应与此保持一致）

```text
┌──────────────────────────── Browser ──────────────────────────────┐
│ React + TypeScript + Vite build → dist/ (production static)       │
│ Workbench V1 | Asset Library V2 | Integrations V3                 │
│ typed API client, no direct Ollama, no runtime CDN/Node           │
└──────────────────────────────┬─────────────────────────────────────┘
                               │ loopback same-origin HTTP
                    ┌──────────▼───────────────┐
                    │ FastAPI App / CLI façade │ ← V2 MCP stdio
                    │ auth boundary + schemas │ ← V3 External adapters
                    └──────────┬───────────────┘
               ┌───────────────┼───────────────────┐
               │               │                   │
         Prompt Compiler  Asset/Revision      Job Coordinator
         pure CPU          SQLite / files     one GPU slot
               │               │                   │
               └───────────────┴───────────┬───────┘
                                           │
                          Ollama VisionProvider (local /api/chat)
                          gemma4:26b (single model)
                                           ▲
                     Pillow / FFmpeg/ffprobe preprocessing (CPU)

R0 对照/提取：已安装 Prompt Assistant ← ONLY SOURCE OF TESTS/RULE IDEAS
V2 optional: PySceneDetect + SQLite FTS5 + MCP Python SDK v2
V3 optional: Navia reference adapter / Narralens contract / ComfyUI REST
```

**生产时不启动 React 开发服务器**；FastAPI 托管 `frontend/dist/` 和同源 `/api/v1/*`。V1 的 Ollama 和 LVW 服务是已存在模型服务+新单体应用，不再引入第三个前端服务。ComfyUI 不作为 V1 运行前置条件。

## 2. 源码结构建议（优先少包、少进程）

```text
lvw/
  backend/
    app/main.py                 # FastAPI+同源静态站点
    app/api/{media,jobs,shots,prompts,health}.py
    app/domain/{schemas,compiler,revision_policy}.py
    app/services/{media_preprocess,ollama_provider,job_runner,assets}.py
    app/repositories/sqlite.py
    app/cli.py
  frontend/
    src/{app,components,features,api,styles}/
    index.html  package.json  package-lock.json  vite.config.ts
  contracts/{shot-spec,prompt-revision,media-ref,model-run}.schema.json
  scripts/{build_portable,verify_offline,backup,restore}/
  tests/{unit,api,integration,e2e,hardware}/
  data/ (outside runtime release at deployment)
```

V1 不引入 React Router/Redux/TanStack Query 等非必要包；基础组件使用 React hooks、fetch、CSS Modules；V2 资产界面复杂度达到明确需求再按 ADR 引入路由/数据请求库。前端复杂交互不能把业务验证逻辑移出 FastAPI。

## 3. 接口与版本合同

- `GET /health` 与 `GET /api/v1/capabilities`（后者显示模型可用但不能泄露文件路径）。
- `POST /api/v1/media` 受控上传/引用，返回 `media_id / sha256 / type`；不接受任意远程 URL。
- `POST /api/v1/jobs/analyze` 返回 202/job_id；`GET jobs/{id}` 轮询；`POST cancel` 幂等；单 GPU 队列。
- `POST /api/v1/shots`、`GET/PUT /api/v1/shots/{id}`（`If-Match: etag`）；`POST /api/v1/prompts/compile` 纯 CPU。
- `POST /api/v1/prompts/revisions` 永久不可变；`GET /api/v1/prompts/revisions/{id}/export` JSON/TXT。
- Web TypeScript 类型按 Pydantic/OpenAPI 衍生，**禁止**手工独立维护一套相互矛盾的业务 Schema。Schema 更新必须通过 TS 类型检查与 API 合同测试。
- 错误 envelope `{error:{code,message,retryable},request_id}`，成功 `{data,request_id,schema_version}`；request_id 贯穿日志，不能记录隐私图像/完整 Prompt 于默认日志。

## 4. VLM 复用策略（原 R0 建议）

**R0 两种技术路径都实测**：

| 路径 | 用处 | 是否 V1 正式依赖 |
|---|---|---|
| A：已装 ComfyUI Prompt Assistant 插件 API | 验证预设规则、VLM 效果、流式/取消语义、找出性能/兼容问题 | **否**；不要求 ComfyUI 运行 |
| B：FastAPI 调用现有 Ollama `/api/chat` | 最终服务的稳定、轻量推理入口 | **是** |

一切可复用的模板/错误用例先记录出处和许可证、校验质量再局部适配；绝不直接复制整套插件并对外宣称 LVW 自研。强制 `127.0.0.1:11434`、本地模型 tag、上下文/输出/帧上限。结构化 JSON Schema 模式优先；解析失败保存 raw 和 `PARSE_PARTIAL`，不丢用户输入。

## 5. 数据模型、写权限与持久化

V1 最小数据库实体（以 `contracts/` 为数据字段源）：

```text
media_ref     id/hash/type/source_root/relative_path/size/created_at
shot_spec     id/schema_version/mode/media_ref?/four_domains/technical/etag
model_run     id/shot_id/attempt/status/model/config_hash/raw_text/parsed/error
prompt_revision id/shot_id/parent_id?/author/prompt_spec_snapshot/hash/created_at
job           id/idempotency_key/attempt_id/status/error/created_at/updated_at
```

SQLite 使用事务、外键、唯一约束、WAL、schema 版本表；Prompt 修订 **append-only**，模型返还后先写 model_run，再生成候选，不写回已经确认的 revision。图/视频媒体文件大对象不入 SQLite。V2 扩展 asset link、shot PTS、FTS5、style recipe revision；不重新定义 V1 对外 ID。

## 6. Job 状态与 GPU 协调

`queued → running → succeeded | failed | cancelled | interrupted`，另有 `cancel_requested` 作为状态/标志。所有处理是可重试 attempt，不同 attempt 记录唯一 ID；进程重启将残留 running 归为 interrupted，须显式重试并重新分配 attempt。**取消晚到的 Ollama 结果不能覆盖当前 job/revision**；持久化尝试版本检查。

单 GPU 信号量=1；视频 V1 优先 4 帧、最大 8 帧、长边<=1280、`num_ctx=4096`、输出上限和超时，可配置但不得默认无限增长。Ollama `keep_alive=0` 请求模型卸载，须真实检测，不把返回成功当显存已经释放。V1 不声称能强制暂停其他独立 ComfyUI 进程；检测忙碌、提示用户，不抢占已有工作。V3 双侧互斥必须有实际控制合同。

## 7. 核心失败路径（不可省）

- 模型缺失/拒答/OOM/JSON 无效/长任务取消：用户手工编辑/保存/编译/导出全可用。
- 非可信图中文字/网页来源：仅进入可见观察或推理文本，不触发工具调用、路径访问或 Shell。
- 历史/科普：观察、摄影推断、用户引用、创作扩展分域，不将模型猜测标记为已证实。
- SQLite 版本冲突：HTTP 409 `REVISION_CONFLICT`，不静默最后写入覆盖。
- 无法正常打包离线：不声明 V1_ACCEPTED；应用代码可标 engineering complete，仍为 gate FAIL/BLOCKED。
