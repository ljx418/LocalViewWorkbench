# 00｜项目群定位、攻击面与冻结决策（v1.1）

## 核心定位

LVW 是 **Visual Prompt & Creative Asset Service**：将图像、短视频及文字创作意图转换为可追溯、可人为修订、可跨生成器编译的镜头语言与 Prompt 资产。**不是导演/剪辑工作台，也不是通用 Agent 框架或图视频生成引擎。**

| 系统 | 权威 | LVW 接口边界 |
|---|---|---|
| Navia | 用户显式保存的网页/视频知识与证据 | V3 仅接收授权 `source_ref`、片段、出处、许可备注，不能获得 cookie/原始浏览器凭据 |
| Narralens | 生产项目、脚本、镜头顺序、审批/复检、最终导出 | V3 接收镜头 brief，返回 `prompt_revision_id`/Prompt/证据建议，禁止篡改其生产状态 |
| LVW | 参考观察、创作意图、风格配方、PromptSpec、Prompt 修订版本 | 唯一写权限在 LVW 业务服务；媒体本体仍属来源系统 |
| Ollama/ComfyUI | VLM推理及图像/视频生成执行 | 作为独立本地执行服务；不管理生产项目或人工内容判断 |
| Codex/Claude Code | 受控开发与工具调用 | 经 API/MCP 白名单，不直接操作其他系统库 |

## 攻击者视角审计（面向工程）

| 风险 | 攻击方式/失败方式 | 最小防线 | 验收 |
|---|---|---|---|
| 数据权威冲突 | 同一镜头多系统互相覆盖 | 只共享引用、版本与建议；`If-Match` 乐观锁 | A06/A12/A19 |
| 提示注入 | 画中字幕/网页内容诱导 Agent 执行操作 | 非可信文本仅作为输入数据，MCP 无 shell/任意路径 | A08/A15/A18 |
| 史实/科学幻觉 | 模型猜年代或科学参数冒充事实 | observation/inference/user_evidence/creative_intent 四域分离 | A04/A12/A22 |
| 内容审批失控 | 新增自动评级/词表阻断人工编辑 | 不建 NSFW 审核节点与内容门禁；保留操作自由 | A01/A05 |
| 供应链膨胀 | 插件自动拉包，开发机移机失效 | Node只构建、锁依赖、win wheelhouse/zip、离线验证 | A09/A11/A21 |
| GPU 争抢 | 26B VLM与视频生成同时常驻 | 单 GPU 任务、上下文上限、`keep_alive=0`、资源诊断 | A07/A10/A20 |
| 受控媒体越权 | 上传路径穿越/异常压缩/大视频 OOM | 根路径、解码像素/时长上限、无 URL 自动下载 | A08 |

## 冻结 ADR

- **ADR-001 业务边界**：LVW 不实现剪辑、内容审批、海量媒体爬取、生产级任务总编排；归 Narralens/Navia/执行工作流负责。
- **ADR-002 后端形态**：本机**模块化单体 FastAPI**，SQLite、受控工件目录、单 GPU Worker。V1 不引入消息队列/微服务。
- **ADR-003 前端（v1.1 变更）**：**React + TypeScript + Vite + CSS Modules/原生 CSS**。V1 单页工作台、可拆模块；V2增加检索视图；V3增加集成状态。明确不使用 Gradio/NiceGUI；Node只为构建器，不在发布时运行。
- **ADR-004 模型与复用**：R0 验证本地 Prompt Assistant（`yawiii/ComfyUI-Prompt-Assistant`）、可合法复用的提示词规则；正式 V1 独立调用本机 Ollama `gemma4:26b`；不复制插件的完整运行栈或要求 ComfyUI启动。
- **ADR-005 结构化输出**：使用 Ollama 原生 `/api/chat` 和官方 `format`/Pydantic Schema（若本机版本支持），将 raw、parsed、human_revision 分离；模型不满足 Schema 时存 raw 和 `PARSE_PARTIAL`。
- **ADR-006 数据**：SQLite 存媒体引用、镜头结构、任务、Prompt 不可变修订与轻索引；文件系统存小工件，视频本体默认不复制。V2 才增强 FTS5 与素材关系。
- **ADR-007 MCP 与集成**：V2 官方 MCP Python SDK v2 stdio 暴露现有业务函数；V3 ComfyUI API/Navia/Narralens 薄合同适配，不重复生成队列。
- **ADR-008 内容自主权**：没有额外自动 NSFW 检测、过滤、审批门禁；模型自身可能拒答，人工路径永远可用。不移除文件、权限和系统安全保护。
- **ADR-009 部署**：单 Windows 原生离线 ZIP；运行时不依赖 Node、外网或 ComfyUI；升级时新旧 release 并行和 SQLite 一致性备份。
- **ADR-010 验收门禁**：22个原 A01–A22 不改号；R0 smoke≠完整验收；未证实的性能、断网与人工质量标 NOT_RUN/BLOCKED。

## 不可跨越的增长红线

发现自建镜头剪辑时间线、独立模型训练平台、通用 AI Agent OS、大规模视频资产去重复制、云服务商路由中心、自动内容审批状态、多套前端框架、多套媒体数据库等，应先停工做范围审计并由用户显式批准路线变更。
