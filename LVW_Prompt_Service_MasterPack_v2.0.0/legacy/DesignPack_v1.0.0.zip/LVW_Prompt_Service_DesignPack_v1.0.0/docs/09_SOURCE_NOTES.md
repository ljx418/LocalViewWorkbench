# 09｜来源、确认口径与开放项

## 来源类型
- **来自当前对话用户**：Navia/Narralens 目标与角色、本机 Agent 的 4090/32GB/Gemma4/Ollama/ComfyUI 清单、对人工内容判断和离线的要求；这些是用户提供的运行基线，**并未由本次工具连接本机验证**。
- **本次外部官方技术核对（2026-10-26）**：Ollama Gemma4 模型库支持 `gemma4:26b` 图片输入；Ollama `/api/chat` 支持 base64 图片、`keep_alive=0`；Ollama 云能力可关闭；FastAPI 静态前端与后台任务指导；MCP Python SDK v2（Python>=3.11）。
- **本包工程判断**：单体 FastAPI/SQLite、V1–V3 范围、性能目标、API、UI 草图、风控与测试集合是新增设计，并不是上述开源仓库已经实现的结果。

## 可访问参考
- https://ollama.com/library/gemma4
- https://docs.ollama.com/capabilities/vision
- https://docs.ollama.com/api/chat
- https://docs.ollama.com/faq
- https://fastapi.tiangolo.com/tutorial/frontend/
- https://py.sdk.modelcontextprotocol.io/
- https://docs.comfy.org/zh-CN/custom-nodes/overview
- https://github.com/NanmiCoder/open-image-prompts （仅候选视觉风格参考库；不是自媒体反推引擎；第一版不做强制依赖）

## 要在 S0 真实复核的事项
- `gemma4:26b` 是否真的在本机 Ollama 提供 Vision，`/api/show` 是否报告能力；某个本地模型标签和它的权重许可证；调用不依赖 Ollama 云端。
- ComfyUI/Python/CUDA 和 Ollama 并行时 GPU 争抢状况；实际运行 Windows GPU 驱动、显存、PID，需先关闭正在生成视频的高占用进程。
- Prompt Assistant 自有模板的许可证和路径；只抽取用户明确许可的规则，不偷偷将旧工作流修改/移动。
- 真实输入：VFR 样本、科学纪录片、风格化影像等，由用户提供并独立验收。

## 本包声明
仅完成文档与 HTML 原型设计，不代表任何后端、MCP、集成、GPU 或离线产品测试已经通过。当前开放项是**产品实施阶段的验收项**，不阻止 Codex 先从只读环境探测开始。
