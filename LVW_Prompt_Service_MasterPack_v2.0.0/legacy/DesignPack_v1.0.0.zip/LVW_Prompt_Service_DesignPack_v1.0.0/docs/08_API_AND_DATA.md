# 08｜API、数据与跨项目合同摘要

## V1 API（后端对前端/CLI，全部 loopback）
| Method | Route | 输入/输出 | V1 |
|---|---|---|---|
| GET | `/health` | 服务状态，不返回秘密与用户路径 | ✅ |
| GET | `/api/v1/capabilities` | Ollama 可用性、所选模型、手动模式可用性 | ✅ |
| POST | `/api/v1/media` | 受控 multipart 上传；返回 media_ref/hash/元数据 | ✅ |
| POST | `/api/v1/jobs/analyze` | media_id、mode、settings、idempotency_key；202 + job_id | ✅ |
| GET | `/api/v1/jobs/{job_id}` | 状态、错误码、model_run 引用 | ✅ |
| POST | `/api/v1/jobs/{job_id}/cancel` | 请求取消；幂等 | ✅ |
| POST | `/api/v1/shots` | 可没有 media_id 的 PromptSpec 创建 | ✅ |
| GET/PUT | `/api/v1/shots/{id}` | 读取/修改；PUT 必须 `If-Match: <etag>` | ✅ |
| POST | `/api/v1/prompts/compile` | 纯 CPU 模板编译，不要求模型 | ✅ |
| POST | `/api/v1/prompts/revisions` | 保存不可变人工/系统修订 | ✅ |
| GET | `/api/v1/prompts/revisions/{id}/export?format=json|txt` | 下载编译结果 | ✅ |
| GET | `/api/v1/assets?q=...` | 本地索引检索 | V2 |
| MCP | `list/get/analyze/compile/save/export` | 业务层调用 | V2 |

## Schema 合同
`contracts/shot-spec.schema.json`：视觉观察 vs 摄影/历史推断 vs 用户证据 vs 创作意图，不得互相转换成“已证实”。
`contracts/prompt-revision.schema.json`：不可变版本、作者、模板/模型追踪、两种语言输出、内容哈希。
`contracts/model-run.schema.json`：raw 不等于 parsed，状态和模型拒答错误是执行状态。
`contracts/media-ref.schema.json`：受控来源、hash/时间信息，绝不接受任意 URL 的静默下载。

## 通用 API Envelope
成功：`{ "data": {...}, "request_id": "...", "schema_version": "v1" }`。
失败：`{ "error": {"code":"MODEL_TIMEOUT", "message":"...", "retryable":true}, "request_id":"..." }`。

## v3 跨项目最小消息
Narralens → LVW：`{external_project_id, external_shot_id, source_refs[], creative_brief, target, request_id, authorization_scope}`。
LVW → Narralens：`{prompt_revision_id, shot_spec_id, model_run_id?, compiled_prompt, evidence_refs[], confidence_notes[], contract_version}`。 
Navia → LVW：`{navia_knowledge_ref, source_url, citation_id, quote_or_summary, saved_by_user, rights_note?}`，显式授权；不能传浏览器内部原始 cookie、token、本机私有路径。
ComfyUI adapter：`{allowed_workflow_id, input_parameters, prompt_revision_id, idempotency_key}`，只返回执行与工件引用，不修改 Narralens 发布状态。

## 版本与演进规则
字段只能向后兼容添加，删除/变义须发新版 schema 和迁移；所有客户端若遇未知字段应忽略但保留持久化原始 JSON；缺失必选字段应显式报错。
