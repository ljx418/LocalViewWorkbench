# 03｜目标架构（轻前端／服务化／资产结构优先）

## 架构图
```
           Web 单页 / CLI                (V2) MCP stdio          (V3) Narralens / Navia
                 │                             │                          │
                 └──────────────────── HTTP & Application Service ─────────┘
                                                   │
                   ┌──────────────┬────────────────┼────────────────┐
                   │              │                │                │
            Prompt Compiler  Asset & Revision   Async Job Manager  Integration Adapters
              不依赖模型       SQLite / 文件       并发=1             V3 only
                   │              │                │
                   └──────────────┴────────────────┤
                                                  Local Model Adapter
                                                  Ollama 127.0.0.1:11434
                                                  gemma4:26b
                                                       │
                                     FFmpeg/Pillow 预处理与解码（CPU）
                   可选 ComfyUI API / Prompt Assistant Adapter（从 V3 起）
```

## 实现选择
- **Web**：最小静态 HTML/CSS/JS，无 SPA 构建链；FastAPI 只提供 API 与静态文件。V2 若界面明显复杂才评估 Svelte/Vite。
- **API**：Python 3.11+、FastAPI/Pydantic、`httpx`（调用 Ollama）、Pillow、标准 SQLite、`ffmpeg/ffprobe` 子进程。
- **任务**：应用服务内有界任务队列 + 数据库存档状态；**不是**长任务放在 HTTP handler 中。单 Worker、GPU semaphore=1，持久化 job_id/attempt_id；进程重启将 stale running 转为 interrupted，明确重试。
- **模型**：不复用 Heretic 编码器为生成 LLM；只调用已存在 `gemma4:26b`，先使用官方 Ollama `POST /api/chat` `images`（REST 图片 base64）。`keep_alive=0` 用于一轮结束后卸载；是否卸载成功需实测。
- **可插拔性**：用 `VisionCaptionProvider` 抽象 `analyze(input,model_settings)->RawModelResponse`；`NullProvider` 适用于手动模式；模型更换不改变 API、PromptSpec schema。
- **资源**：默认长边 1280、`num_ctx=4096`、单请求 1 图或 4 视频关键帧（可升 8）；限制总像素、时长、输出 tokens；视频先抽帧再多图传入。V2 精确 PTS；V1 允许近似时间但必须标明“采样时间，非帧精确”。

## V1 数据表（SQLite）
```
media_ref(id, kind, source_path, sha256, bytes, mime, created_at, trust_scope)
shot_spec(id, schema_version, media_id?, mode, observation_json, inference_json,
          user_evidence_json, creative_json, technical_json, etag, created_at, updated_at)
model_run(id, shot_spec_id?, model_name, params_json, status, raw_text, parsed_json?,
          error_code?, timings_json, run_hash, created_at)
prompt_revision(id, shot_spec_id, revision_no, base_etag, authored_by,
                template_id, target, zh_text, en_text, input_hash, immutable_hash, created_at)
job(id, kind, input_hash, status, attempt, error_code?, started_at?, finished_at?)
template(id, mode, target, version, editable_fields_json, body_text)
```
所有 ID 用 UUID/ULID；模板版本与模型参数入修订；数据库不存图片二进制；用户已有媒体默认按受控路径引用，明确选择才复制。

## 核心命令处理/错误语义
- `analyze_media` 只写 `model_run` 和机器建议；**不直接更新人工 revision**。
- `compile_prompt` 是纯业务函数：`PromptSpec + Template + Target -> PromptDraft`，不访问 GPU；即使 Ollama 停机仍可执行。
- `save_revision` 必须提供上一版 `etag`，冲突返回 `REVISION_CONFLICT`；写后生成内容哈希，后续只读。
- 取消先持久化 `cancel_requested`，worker 在可中断点检查；迟到成功结果不得覆盖取消结果或手工修订。
- 失败可保留 `model_run.raw_text`；错误码 `MODEL_UNAVAILABLE`、`MODEL_REFUSAL`、`MODEL_TIMEOUT`、`PARSE_PARTIAL`、`CUDA_OOM`、`INVALID_MEDIA`、`PATH_NOT_ALLOWED`、`REVISION_CONFLICT`、`JOB_CANCELLED`。

## 资产生命周期
V1：导入受控引用、PromptSpec、不可变 revision、导出。V2：镜头和素材多对多引用、哈希去重、检索、独立标签/配方、项目级备份恢复。V3：跨项目外键引用 (`origin`,`external_id`,`external_version`)，状态和访问范围映射；原媒体权威永不由 LVW 抢占。

## 运行时依赖控制
V1 禁止添加 Redis/PostgreSQL/Celery/第二个 GUI/第二个大模型或“万能 Agent 框架”，除非经依赖影响审计确认必要并保留回滚；工具包与模型包分离。V3 ComfyUI 调用只接受已知 workflow ID + schema 参数，不允许外部 Agent 提交任意 Python 节点执行。
