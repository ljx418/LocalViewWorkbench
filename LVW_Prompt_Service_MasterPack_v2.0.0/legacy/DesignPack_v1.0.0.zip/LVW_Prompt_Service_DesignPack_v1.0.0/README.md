# LVW Prompt Service｜视觉提示词与镜头创作资产服务

> 设计包版本 1.0.0 | 2026-10-26 | 状态：**IMPLEMENTATION_GUIDANCE_ONLY**（可指导开发；没有验证应用已实现）

**先看 `START_HERE.html`；本地 Codex 从 `CODEX_START.md` 开始。** HTML 离线打开，无外部依赖；交互是原型演示，不调用实际推理 API。

## 一句话定位
本项目向 Narralens 等消费者提供可追溯、可人工编辑的镜头意图、视觉反推结果、Prompt 编译、版本及风格配方；**它不是剪辑器、不是素材爬虫、不是视频生成器，也不是内容审批平台**。

## 项目群角色
- **Navia / 输入耳目**：网页与公开视频的证据化理解、显式收藏和知识来源；只输出经过授权的链接、摘要及来源引用。
- **Narralens / 生产主控**：脚本、镜头任务、生产排期、质量复检、剪辑、版权与最终导出，持有 `project_id`/`shot_id` 的最终生产权威。
- **LVW Prompt Service / 专业能力**：图/短视频视觉观察、人工镜头意图、风格配方、Prompt 编译和修订、资产引用；持有 `prompt_revision_id` 的权威。
- **ComfyUI / Ollama / 本地生图视频执行**：推理与生成执行，不拥有项目级审核、剪辑或资产真实来源。
- **Codex/Claude Code / 开发与受控脚本**：可调用工具但不能绕过文件权限、工作流白名单和数据写入合同。

## 当前用户机条件（**用户提供的盘点，需 S0 在目标 Windows 主机上复核**）
RTX 4090 24GB、RAM 32GB、Windows、已安装 ComfyUI 0.37.0 / Prompt Assistant、Ollama `http://127.0.0.1:11434`、本地 `gemma4:26b` Q4_K_M，已有 Florence-2、Qwen3-14B 等。V1 不下载新模型，不依赖 ComfyUI 正常启动，不重用缺少 lm_head 的 H3 编码器进行文字生成。

## 目录
- `docs/00_POSITION_AND_ADR.md`：分工、风险、关键架构决策
- `docs/01_PRD.md`：问题、用户、场景、功能范围、需求编号
- `docs/02_UX_TARGET.md`：目标体验、交互流、异常与人工优先
- `docs/03_ARCHITECTURE.md`：组件、任务、资产、模型适配、数据权威
- `docs/04_ROADMAP.md`：V1–V3 范围与阶段门槛
- `docs/05_BUILD_PLAN.md`：按任务可执行的开发步骤
- `docs/06_ACCEPTANCE.md`：真实验收、样本、退出标准与证据
- `docs/07_SECURITY_AND_MIGRATION.md`：攻击面、离线、权限、迁移
- `docs/08_API_AND_DATA.md`：核心接口、错误码、数据结构
- `docs/09_SOURCE_NOTES.md`：来源与未经确认事项
- `plans/tasks.json`、`plans/acceptance_cases.json`：机器可读开发/测试计划
- `contracts/*.schema.json`、`examples/*`：数据合同与样本
- `START_HERE.html`：浏览器总览+体验原型
- `tools/verify_pack.py`：文档包静态校验，**不是产品验收**

## 不可忽略的决策
1. **V1 优先价值闭环**：参考图/短片→视觉反推→六类风格模板→手改→编译多种目标 Prompt→保存版本/导出；无额外 NSFW 审核节点。
2. **用户对内容作判断**：没有 NSFW 自动评级、审批门槛、敏感词拦截；模型级拒答不可保证消除。模型失败不影响手写、保存、导出。
3. **轻前端，服务化后端，结构化资产库**：V1 单体 FastAPI+静态页+SQLite+受管文件；V2 强化检索与镜头资产；V3 做跨项目协议与生产集成。
4. **资产不重复复制**：上游原媒体保留原系统权威，LVW 保存引用/摘要/哈希及用户选择的缓存，不默认复制全片。
5. **最小依赖、可恢复、完全离线**：Ollama 原生 HTTP API；图片 Pillow；视频 FFmpeg；不默认安装第二套大模型、Redis、PostgreSQL 或新 ComfyUI 节点。

## 验收状态
本包只提供可执行计划与设计合同。`PASS` 只能来自目标机真实日志、应用测试、样本评测和可复查证据；文档静态校验不等于 V1/V2/V3 已交付。
