# Codex 开发启动指令｜LVW Prompt Service

你是本项目的实施和验收执行者。根目录 `README.md`、`docs/`、`contracts/` 与 `plans/` 是当前 V1–V3 的唯一开发基线；`START_HERE.html` 是只读产品演示，不可把原型的模拟按钮当成业务实现。

## 必须先做
1. 从 `docs/00_POSITION_AND_ADR.md` 到 `docs/09_SOURCE_NOTES.md` 依次阅读，读取 `plans/tasks.json`、`plans/acceptance_cases.json`、全部 JSON Schema。
2. 运行 `python tools/verify_pack.py`；它只验证设计包结构，不证明产品通过。
3. **先做 S0 只读盘点**：git status、Windows GPU/RAM、Ollama 模型是否已安装、vision 能力与 ComfyUI/Prompt Assistant 位置。不得破坏现有安装，不得默认下载新模型。
4. 以 `gemma4:26b`、`http://127.0.0.1:11434` 为候选；真实 /api/chat 图片探测若失败，保留手工路径，记录事实，切勿假装已成功。

## 实施顺序
严格依 `plans/tasks.json` S0→S11；**优先交付 V1，再推进 V2、V3，禁止三个版本混开发**。每阶段包含代码、测试、文档更新、真实运行记录。V1 开发使用 Windows 原生环境，优先复用现有 Ollama 而非新拉 LLM、重装 ComfyUI 或跑新模型服务器。

## 禁止事项
- 不新增内容 NSFW 自动分类器、审查 API、敏感词阻断、强制审批状态；模型拒答时手工模式可用。不声称保证模型内部从不拒答。
- 不接入云端图像推理，不启动默认自动下载，不暴露到 0.0.0.0，不让图片字幕/提示词执行 Shell 或外部工具。
- 不在 V1 引入 Redis/Postgres/Celery/FiftyOne/LangGraph/Dify、GPU 推理二次框架或新视频生成模型；不能为了“架构完整”而多造平台。
- 不修改 Narralens/Navia 主库和已有生产工作流；V3 通过合同适配、用户授权与只读建议集成。
- 不把 fixture/mock/README/测试脚本自生成标注当作真实业务质量验证。

## V1 最低交付
1. 可启动的 HTTP 服务 + 单页 Web + CLI。
2. 图片、短视频抽帧→Ollama Vision→原文/建议→人工草稿，六模式、四目标编译。
3. 单 GPU任务、失败局部化、模型卸载、版本保存、TXT/JSON 导出。
4. SQLite/受管文件与路径保护，离线冷启动、迁移备份与回滚。
5. 对应 API、测试、日志、用户安装运行说明、真实资源数据。

## 每阶段报告格式
`stage`, `git_sha`, `environment`, `changed_files`, `run_commands`, `passed_tests`, `failed_tests`, `blocked_tests`, `real_gpu_evidence`, `network_evidence`, `remaining_risks`, `next_gate`。
状态只允许 PASS/FAIL/BLOCKED/NOT_RUN。仅全部 V1 P0 实测通过时声明 `V1_ACCEPTED`，V2/V3 以相同规则推进；质量数据不足则 `ENGINEERING_READY / QUALITY_PENDING`。

## 第一条执行命令
在目标项目仓库的 Codex 终端直接输入：
> 请阅读当前文档包 README、CODEX_START、docs、contracts、plans，先执行 S0 只读设备/软件/模型核验并提交基线报告。随后按 S1–S5 完成 V1 实现与验收；每阶段测试、修复、复跑后再前进。未验证的真实资源、离线或人工质量项目必须明确标 BLOCKED/NOT_RUN，不得伪造 PASS。V1 通过后再根据计划开展 V2/V3，不得提前扩展范围，也不得修改现有 ComfyUI 与 Narralens/ Navia 项目。
