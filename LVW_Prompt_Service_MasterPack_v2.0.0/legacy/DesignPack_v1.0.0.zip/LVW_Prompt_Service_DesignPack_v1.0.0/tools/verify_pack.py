#!/usr/bin/env python3
"""Documentation-pack static checks. NEVER treat this as product or GPU acceptance."""
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parent.parent
needed=['README.md','CODEX_START.md','START_HERE.html'] + [f'docs/{x}' for x in [
 '00_POSITION_AND_ADR.md','01_PRD.md','02_UX_TARGET.md','03_ARCHITECTURE.md',
 '04_ROADMAP.md','05_BUILD_PLAN.md','06_ACCEPTANCE.md','07_SECURITY_AND_MIGRATION.md',
 '08_API_AND_DATA.md','09_SOURCE_NOTES.md']]
needed += ['plans/tasks.json','plans/acceptance_cases.json','contracts/shot-spec.schema.json',
 'contracts/prompt-revision.schema.json','contracts/media-ref.schema.json','contracts/model-run.schema.json']
errors=[];checks=0
for name in needed:
    checks+=1
    if not (ROOT/name).is_file():errors.append('MISSING '+name)
all_json={}
for path in ROOT.rglob('*.json'):
    checks+=1
    try:all_json[str(path.relative_to(ROOT))]=json.loads(path.read_text('utf8'))
    except Exception as e:errors.append(f'BAD JSON {path.name}: {e}')
tasks=all_json.get('plans/tasks.json',{}).get('tasks',[])
cases=all_json.get('plans/acceptance_cases.json',{}).get('cases',[])
checks+=4
if len(tasks)!=12: errors.append('Expected S0-S11 tasks')
if len(cases)!=22: errors.append('Expected 22 acceptance cases')
case_ids={c.get('case_id') for c in cases}
if case_ids != {f'A{i:02d}' for i in range(1,23)}:errors.append('Acceptance case IDs mismatch')
if {t.get('task_id') for t in tasks}!={f'S{i}' for i in range(12)}:errors.append('Task IDs mismatch')
covered=set()
for t in tasks:
    checks+=1
    refs=set(t.get('acceptance_ids',[]));covered|=refs
    if not refs.issubset(case_ids):errors.append('Unknown tests on '+t['task_id'])
if covered!=case_ids: errors.append('Some tests have no stage: '+str(case_ids-covered))
for c in cases:
    checks+=1
    if c.get('status')!='NOT_RUN' or c.get('evidence_path') is not None: errors.append('Product claims not NOT_RUN: '+str(c.get('case_id')))
html=(ROOT/'START_HERE.html').read_text('utf8')
checks+=1
if any(x in html.lower() for x in ['src="https://','href="https://fonts','src="http://','@import url(']):errors.append('HTML remote runtime resource')
for href in re.findall(r'href="([^"]+)"',html):
    if href.startswith(('#','https:','http:','mailto:')):continue
    checks+=1
    if not (ROOT/href).is_file():errors.append('BROKEN HTML LINK '+href)
print('Static pack checks:',checks,'Errors:',len(errors))
for e in errors:print('FAIL:',e)
print('REMINDER: This is only documentation validation; actual app/GPU/offline acceptance remains NOT_RUN.')
sys.exit(1 if errors else 0)
